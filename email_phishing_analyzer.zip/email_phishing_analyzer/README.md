# PhishGuard — AI Email Phishing Analyzer
### Final Year Project | Python + Flask + Claude AI

---

## 🗂 Project Structure

```
email_phishing_analyzer/
│
├── app.py                    ← Flask backend (all logic lives here)
├── requirements.txt          ← Python dependencies
├── README.md                 ← This file
│
├── templates/
│   └── index.html            ← Main HTML page (Jinja2 template)
│
├── static/
│   ├── css/style.css         ← All styling
│   └── js/main.js            ← Frontend logic (fetch API, render results)
│
└── uploads/                  ← Temporary storage for uploaded .eml files
```

---

## ⚙️ How It Works (Concept)

```
User pastes email / uploads .eml
          ↓
Flask backend receives it
          ↓
email module parses it into:
  • Headers (From, Reply-To, SPF, DKIM...)
  • Body (plain text + HTML)
  • URLs (extracted with regex)
  • Attachments (listed with filenames + size)
  • Sender info (Return-Path, Message-ID, hops)
          ↓
All components sent to Claude AI as a structured prompt
          ↓
Claude returns JSON: verdict, scores, findings, red flags
          ↓
Frontend renders the full threat report
```

---

## 🚀 Setup & Run

### Step 1 — Install dependencies
```bash
pip install -r requirements.txt
```

### Step 2 — Set your Anthropic API key
**Windows:**
```cmd
set ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxx
```
**Mac/Linux:**
```bash
export ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxx
```

### Step 3 — Run the app
```bash
python app.py
```

### Step 4 — Open in browser
```
http://localhost:5000
```

---

## 📌 What Gets Analyzed

| Component         | What Claude Looks For |
|-------------------|-----------------------|
| **Email Headers** | SPF/DKIM/DMARC failures, forged From field, suspicious X-Mailer |
| **Sender Info**   | Domain mismatch, free email providers, suspicious IPs |
| **Body Text**     | Urgency language, impersonation, grammar issues, credential requests |
| **URLs**          | Domain spoofing, URL shorteners, mismatched link text vs href |
| **Attachments**   | Dangerous file types (.exe, .js, .vbs, macros in Office files) |

---

## 📊 Output Format

Claude returns a JSON report with:
- `verdict`: SAFE / SUSPICIOUS / PHISHING
- `confidence_score`: 0–100
- `risk_level`: LOW / MEDIUM / HIGH / CRITICAL
- `summary`: Plain English explanation
- Per-component analysis with scores and findings
- `red_flags`: Specific threats detected
- `recommendations`: Actions to take

---

## 🔑 API Key

Get your free Anthropic API key at: https://console.anthropic.com
This project uses the `claude-opus-4-5` model.

---

## 📝 Notes for Your FYP Report

- The email parsing uses Python's built-in `email` module (no extra library needed)
- URL extraction uses regex — no external URL checker API needed
- All analysis intelligence comes from Claude's reasoning, not hardcoded rules
- The app is stateless — no database, emails are never stored permanently
