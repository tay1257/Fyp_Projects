"""
Email Phishing Analyzer - Flask Backend
Uses Claude AI (Anthropic) to analyze emails for phishing threats.
"""

from flask import Flask, request, jsonify, render_template
import anthropic
import email
import email.policy
import re
import os
import json
import base64
from werkzeug.utils import secure_filename

# ─── App Setup ────────────────────────────────────────────────────────────────
app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = "uploads"
app.config["MAX_CONTENT_LENGTH"] = 10 * 1024 * 1024  # 10 MB max upload

ALLOWED_EXTENSIONS = {"eml", "txt", "msg"}

# Initialize Anthropic client (reads ANTHROPIC_API_KEY from environment)
client = anthropic.Anthropic()


# ─── Helper Functions ─────────────────────────────────────────────────────────

def allowed_file(filename):
    """Check if the uploaded file extension is allowed."""
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def extract_urls(text):
    """Extract all URLs found in a block of text."""
    url_pattern = re.compile(
        r"(https?://[^\s<>\"\']+|www\.[^\s<>\"\']+)", re.IGNORECASE
    )
    return list(set(url_pattern.findall(text)))


def extract_sender_info(msg):
    """
    Extract sender-related headers for reputation analysis.
    Returns a dict with From, Reply-To, Return-Path, Received headers.
    """
    sender_info = {
        "from": msg.get("From", "N/A"),
        "reply_to": msg.get("Reply-To", "N/A"),
        "return_path": msg.get("Return-Path", "N/A"),
        "message_id": msg.get("Message-ID", "N/A"),
        "received": msg.get_all("Received", []),  # list of all hops
    }
    return sender_info


def extract_headers(msg):
    """
    Extract important email headers relevant to phishing detection.
    Includes SPF, DKIM, DMARC results if present.
    """
    headers = {}
    important_headers = [
        "From", "To", "Subject", "Date", "Reply-To",
        "Return-Path", "Message-ID", "X-Originating-IP",
        "Received-SPF", "DKIM-Signature", "Authentication-Results",
        "X-Mailer", "X-Spam-Status", "X-Spam-Score",
    ]
    for h in important_headers:
        value = msg.get(h)
        if value:
            headers[h] = value
    return headers


def extract_body(msg):
    """
    Walk the email MIME structure and extract all text parts (plain + HTML).
    Returns a dict: { "plain": "...", "html": "..." }
    """
    body = {"plain": "", "html": ""}

    if msg.is_multipart():
        for part in msg.walk():
            ctype = part.get_content_type()
            disposition = str(part.get("Content-Disposition", ""))

            # Skip attachments when extracting body
            if "attachment" in disposition:
                continue

            if ctype == "text/plain":
                body["plain"] += part.get_payload(decode=True).decode(
                    part.get_content_charset() or "utf-8", errors="replace"
                )
            elif ctype == "text/html":
                body["html"] += part.get_payload(decode=True).decode(
                    part.get_content_charset() or "utf-8", errors="replace"
                )
    else:
        # Simple non-multipart email
        payload = msg.get_payload(decode=True)
        if payload:
            body["plain"] = payload.decode(
                msg.get_content_charset() or "utf-8", errors="replace"
            )

    return body


def extract_attachments(msg):
    """
    List all attachments found in the email.
    Returns a list of dicts: { filename, content_type, size_kb }
    """
    attachments = []
    if msg.is_multipart():
        for part in msg.walk():
            disposition = str(part.get("Content-Disposition", ""))
            if "attachment" in disposition:
                filename = part.get_filename() or "unknown"
                payload = part.get_payload(decode=True) or b""
                attachments.append({
                    "filename": filename,
                    "content_type": part.get_content_type(),
                    "size_kb": round(len(payload) / 1024, 2),
                })
    return attachments


def parse_email_content(raw_text):
    """
    Parse raw email text (from .eml file or pasted content) into
    structured components ready for AI analysis.
    """
    try:
        msg = email.message_from_string(raw_text, policy=email.policy.default)
    except Exception:
        # Fallback: treat the whole thing as plain body text
        return {
            "headers": {},
            "sender_info": {},
            "body": {"plain": raw_text, "html": ""},
            "urls": extract_urls(raw_text),
            "attachments": [],
            "parse_error": True,
        }

    body = extract_body(msg)
    combined_text = body["plain"] + " " + body["html"]

    return {
        "headers": extract_headers(msg),
        "sender_info": extract_sender_info(msg),
        "body": body,
        "urls": extract_urls(combined_text),
        "attachments": extract_attachments(msg),
        "parse_error": False,
    }


def build_analysis_prompt(parsed):
    """
    Build the detailed prompt sent to Claude for phishing analysis.
    Structures each component clearly so Claude can reason about each.
    """
    headers_str = json.dumps(parsed["headers"], indent=2)
    sender_str = json.dumps(parsed["sender_info"], indent=2)
    urls_str = "\n".join(parsed["urls"]) if parsed["urls"] else "None found"
    attachments_str = (
        json.dumps(parsed["attachments"], indent=2)
        if parsed["attachments"]
        else "None"
    )
    body_text = parsed["body"]["plain"][:3000]  # Limit to avoid token overrun

    prompt = f"""
You are a cybersecurity expert specializing in email phishing detection.
Analyze the following email components and produce a structured JSON threat report.

══════════════════════════════════
EMAIL HEADERS:
{headers_str}

══════════════════════════════════
SENDER INFORMATION:
{sender_str}

══════════════════════════════════
EMAIL BODY (first 3000 chars):
{body_text}

══════════════════════════════════
URLS FOUND:
{urls_str}

══════════════════════════════════
ATTACHMENTS:
{attachments_str}

══════════════════════════════════

Analyze ALL components above for phishing indicators. Return ONLY valid JSON (no markdown, no extra text) with this exact structure:

{{
  "verdict": "SAFE" | "SUSPICIOUS" | "PHISHING",
  "confidence_score": <integer 0-100>,
  "risk_level": "LOW" | "MEDIUM" | "HIGH" | "CRITICAL",
  "summary": "<2-3 sentence plain English summary of your finding>",
  "header_analysis": {{
    "score": <0-100>,
    "findings": ["<finding1>", "<finding2>"]
  }},
  "sender_analysis": {{
    "score": <0-100>,
    "findings": ["<finding1>", "<finding2>"]
  }},
  "body_analysis": {{
    "score": <0-100>,
    "findings": ["<finding1>", "<finding2>"]
  }},
  "url_analysis": {{
    "score": <0-100>,
    "suspicious_urls": ["<url>"],
    "findings": ["<finding1>", "<finding2>"]
  }},
  "attachment_analysis": {{
    "score": <0-100>,
    "findings": ["<finding1>", "<finding2>"]
  }},
  "red_flags": ["<specific red flag 1>", "<specific red flag 2>"],
  "recommendations": ["<action 1>", "<action 2>", "<action 3>"]
}}

Be thorough. Score 0 = completely safe, 100 = definitely malicious.
"""
    return prompt


def analyze_with_claude(parsed):
    """
    Send the structured email data to Claude API and get back a phishing report.
    Returns the parsed JSON report dict.
    """
    prompt = build_analysis_prompt(parsed)

    message = client.messages.create(
        model="claude-opus-4-5",
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}],
    )

    raw_response = message.content[0].text.strip()

    # Strip markdown code fences if Claude added them
    if raw_response.startswith("```"):
        raw_response = re.sub(r"^```[a-z]*\n?", "", raw_response)
        raw_response = re.sub(r"\n?```$", "", raw_response)

    return json.loads(raw_response)


# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    """Serve the main frontend page."""
    return render_template("index.html")


@app.route("/analyze/text", methods=["POST"])
def analyze_text():
    """
    Analyze email pasted directly as text.
    Expects JSON body: { "email_text": "..." }
    """
    data = request.get_json()
    if not data or not data.get("email_text", "").strip():
        return jsonify({"error": "No email text provided."}), 400

    raw_text = data["email_text"]
    parsed = parse_email_content(raw_text)
    report = analyze_with_claude(parsed)

    # Attach the extracted components so frontend can display them
    report["extracted"] = {
        "headers": parsed["headers"],
        "sender_info": parsed["sender_info"],
        "urls": parsed["urls"],
        "attachments": parsed["attachments"],
    }

    return jsonify(report)


@app.route("/analyze/file", methods=["POST"])
def analyze_file():
    """
    Analyze an uploaded .eml or .txt email file.
    Expects multipart form data with field 'email_file'.
    """
    if "email_file" not in request.files:
        return jsonify({"error": "No file uploaded."}), 400

    file = request.files["email_file"]

    if file.filename == "":
        return jsonify({"error": "Empty filename."}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "Only .eml and .txt files are supported."}), 400

    filename = secure_filename(file.filename)
    save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(save_path)

    with open(save_path, "r", encoding="utf-8", errors="replace") as f:
        raw_text = f.read()

    parsed = parse_email_content(raw_text)
    report = analyze_with_claude(parsed)

    report["extracted"] = {
        "headers": parsed["headers"],
        "sender_info": parsed["sender_info"],
        "urls": parsed["urls"],
        "attachments": parsed["attachments"],
    }

    # Clean up uploaded file after analysis
    os.remove(save_path)

    return jsonify(report)


# ─── Entry Point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    os.makedirs("uploads", exist_ok=True)
    print("Starting Email Phishing Analyzer...")
    print("Open http://localhost:5000 in your browser.")
    app.run(debug=True, port=5000)
