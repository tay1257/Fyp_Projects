/**
 * PhishGuard — Frontend JavaScript
 * Handles: tab switching, file upload drag/drop, API calls, result rendering
 */

// ─── Element References ────────────────────────────────────────────────────

const tabs         = document.querySelectorAll(".tab");
const tabContents  = document.querySelectorAll(".tab-content");
const inputSection = document.querySelector(".input-section");
const loadingEl    = document.getElementById("loading");
const resultsEl    = document.getElementById("results");

// Paste tab
const emailTextarea     = document.getElementById("email-text");
const btnAnalyzeText    = document.getElementById("btn-analyze-text");

// Upload tab
const uploadZone        = document.getElementById("upload-zone");
const fileInput         = document.getElementById("file-input");
const fileSelectedEl    = document.getElementById("file-selected");
const fileNameEl        = document.getElementById("file-name");
const btnClearFile      = document.getElementById("btn-clear-file");
const btnAnalyzeFile    = document.getElementById("btn-analyze-file");

// Result elements
const verdictCard       = document.getElementById("verdict-card");
const verdictIcon       = document.getElementById("verdict-icon");
const verdictText       = document.getElementById("verdict-text");
const ringFill          = document.getElementById("ring-fill");
const ringScore         = document.getElementById("ring-score");
const summaryText       = document.getElementById("summary-text");
const flagsBox          = document.getElementById("flags-box");
const flagsList         = document.getElementById("flags-list");
const recoList          = document.getElementById("reco-list");
const btnReset          = document.getElementById("btn-reset");


// ─── Tab Switching ─────────────────────────────────────────────────────────

tabs.forEach(tab => {
  tab.addEventListener("click", () => {
    tabs.forEach(t => t.classList.remove("active"));
    tabContents.forEach(c => c.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById("tab-" + tab.dataset.tab).classList.add("active");
  });
});


// ─── File Upload (click + drag/drop) ──────────────────────────────────────

uploadZone.addEventListener("click", () => fileInput.click());

fileInput.addEventListener("change", () => {
  if (fileInput.files[0]) setSelectedFile(fileInput.files[0]);
});

uploadZone.addEventListener("dragover", e => {
  e.preventDefault();
  uploadZone.classList.add("drag-over");
});

uploadZone.addEventListener("dragleave", () => {
  uploadZone.classList.remove("drag-over");
});

uploadZone.addEventListener("drop", e => {
  e.preventDefault();
  uploadZone.classList.remove("drag-over");
  const file = e.dataTransfer.files[0];
  if (file) setSelectedFile(file);
});

function setSelectedFile(file) {
  fileNameEl.textContent = file.name;
  fileSelectedEl.style.display = "flex";
  uploadZone.style.display = "none";
  btnAnalyzeFile.disabled = false;
  // Store the file object for later use
  btnAnalyzeFile.dataset.ready = "1";
  window._selectedFile = file;
}

btnClearFile.addEventListener("click", () => {
  fileInput.value = "";
  window._selectedFile = null;
  fileSelectedEl.style.display = "none";
  uploadZone.style.display = "block";
  btnAnalyzeFile.disabled = true;
});


// ─── Analyze — Paste Text ─────────────────────────────────────────────────

btnAnalyzeText.addEventListener("click", async () => {
  const text = emailTextarea.value.trim();
  if (!text) {
    alert("Please paste some email content first.");
    return;
  }
  showLoading();
  try {
    const response = await fetch("/analyze/text", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email_text: text }),
    });
    const data = await response.json();
    if (data.error) throw new Error(data.error);
    renderResults(data);
  } catch (err) {
    hideLoading();
    alert("Analysis failed: " + err.message);
  }
});


// ─── Analyze — File Upload ─────────────────────────────────────────────────

btnAnalyzeFile.addEventListener("click", async () => {
  if (!window._selectedFile) return;

  const formData = new FormData();
  formData.append("email_file", window._selectedFile);

  showLoading();
  try {
    const response = await fetch("/analyze/file", {
      method: "POST",
      body: formData,
    });
    const data = await response.json();
    if (data.error) throw new Error(data.error);
    renderResults(data);
  } catch (err) {
    hideLoading();
    alert("Analysis failed: " + err.message);
  }
});


// ─── Loading State ─────────────────────────────────────────────────────────

function showLoading() {
  inputSection.style.display = "none";
  loadingEl.style.display = "block";
  resultsEl.style.display = "none";
}

function hideLoading() {
  inputSection.style.display = "block";
  loadingEl.style.display = "none";
}


// ─── Render Results ────────────────────────────────────────────────────────

/**
 * Main function that takes the API JSON response and
 * populates every section of the results UI.
 */
function renderResults(data) {
  loadingEl.style.display = "none";
  resultsEl.style.display = "block";

  // Scroll to results smoothly
  resultsEl.scrollIntoView({ behavior: "smooth" });

  // 1. Verdict Card
  renderVerdict(data);

  // 2. Summary
  summaryText.textContent = data.summary || "No summary provided.";

  // 3. Red Flags
  renderList(flagsList, data.red_flags || []);
  flagsBox.style.display = (data.red_flags && data.red_flags.length) ? "block" : "none";

  // 4. Analysis cards
  renderAnalysisCard("header",     data.header_analysis);
  renderAnalysisCard("sender",     data.sender_analysis);
  renderAnalysisCard("body",       data.body_analysis);
  renderAnalysisCard("attachment", data.attachment_analysis);
  renderUrlCard(data.url_analysis);

  // 5. Extracted data
  renderExtracted(data.extracted);

  // 6. Recommendations
  renderList(recoList, data.recommendations || []);
}


function renderVerdict(data) {
  const verdict = data.verdict || "UNKNOWN";
  const score   = data.confidence_score || 0;

  // Icon mapping
  const icons = { SAFE: "🛡", SUSPICIOUS: "⚠️", PHISHING: "☠️" };
  verdictIcon.textContent = icons[verdict] || "❓";
  verdictText.textContent = verdict;

  // Apply color class to card
  verdictCard.className = "verdict-card verdict-" + verdict;

  // Confidence ring — circumference of r=32 circle = ~201px
  const circumference = 201;
  const offset = circumference - (score / 100) * circumference;
  ringFill.style.strokeDashoffset = offset;

  // Ring color by verdict
  const colors = { SAFE: "#00d4aa", SUSPICIOUS: "#ff6b35", PHISHING: "#ff3b5c" };
  ringFill.style.stroke = colors[verdict] || "#8b949e";

  ringScore.textContent = score + "%";
}


/**
 * Render a single analysis card (header, sender, body, attachment).
 * @param {string} id - matches element id suffix (e.g. "header" → score-header)
 * @param {object} analysis - { score, findings }
 */
function renderAnalysisCard(id, analysis) {
  if (!analysis) return;

  const scoreEl    = document.getElementById("score-" + id);
  const findingsEl = document.getElementById("findings-" + id);
  const score      = analysis.score || 0;

  // Score bar width + color
  scoreEl.style.width = score + "%";
  scoreEl.style.background = scoreColor(score);

  // Findings list
  findingsEl.innerHTML = "";
  (analysis.findings || []).forEach(f => {
    const li = document.createElement("li");
    li.textContent = f;
    findingsEl.appendChild(li);
  });
}


function renderUrlCard(analysis) {
  if (!analysis) return;

  const scoreEl   = document.getElementById("score-url");
  const findingsEl= document.getElementById("findings-url");
  const suspBlock = document.getElementById("suspicious-urls-block");
  const suspList  = document.getElementById("suspicious-urls-list");
  const score     = analysis.score || 0;

  scoreEl.style.width = score + "%";
  scoreEl.style.background = scoreColor(score);

  findingsEl.innerHTML = "";
  (analysis.findings || []).forEach(f => {
    const li = document.createElement("li");
    li.textContent = f;
    findingsEl.appendChild(li);
  });

  if (analysis.suspicious_urls && analysis.suspicious_urls.length) {
    suspBlock.style.display = "block";
    suspList.innerHTML = "";
    analysis.suspicious_urls.forEach(url => {
      const li = document.createElement("li");
      li.textContent = url;
      suspList.appendChild(li);
    });
  } else {
    suspBlock.style.display = "none";
  }
}


function renderExtracted(extracted) {
  if (!extracted) return;

  // Headers
  const headersEl = document.getElementById("ext-headers");
  const headers   = extracted.headers || {};
  const headerLines = Object.entries(headers).map(([k, v]) => `${k}: ${v}`);
  headersEl.textContent = headerLines.length
    ? headerLines.join("\n")
    : "No important headers found";

  // URLs
  const urlsEl = document.getElementById("ext-urls");
  const urls   = extracted.urls || [];
  urlsEl.textContent = urls.length ? urls.join("\n") : "No URLs found";
}


function renderList(el, items) {
  el.innerHTML = "";
  items.forEach(item => {
    const li = document.createElement("li");
    li.textContent = item;
    el.appendChild(li);
  });
}


/**
 * Returns a color based on 0-100 threat score.
 * Green = safe, Orange = suspicious, Red = phishing
 */
function scoreColor(score) {
  if (score < 35) return "#00d4aa";   // teal — low risk
  if (score < 65) return "#ff6b35";   // orange — medium
  return "#ff3b5c";                   // red — high risk
}


// ─── Reset Button ──────────────────────────────────────────────────────────

btnReset.addEventListener("click", () => {
  resultsEl.style.display = "none";
  inputSection.style.display = "block";
  emailTextarea.value = "";
  // Reset file upload state
  window._selectedFile = null;
  fileInput.value = "";
  fileSelectedEl.style.display = "none";
  uploadZone.style.display = "block";
  btnAnalyzeFile.disabled = true;
  // Scroll back to top
  window.scrollTo({ top: 0, behavior: "smooth" });
});
